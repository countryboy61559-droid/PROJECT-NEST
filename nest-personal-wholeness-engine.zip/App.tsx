
import React, { useState, useEffect, useCallback } from 'react';
import { UserProfile, JourneyPhase } from './types';
import { STRENGTHS_MAPPING, WEEKLY_CURRICULUM } from './constants';
import Dashboard from './components/Dashboard';
import MeditationLab from './components/MeditationLab';
import ProfileForm from './components/ProfileForm';
import HeroGallery from './components/HeroGallery';
import JourneyTracker from './components/JourneyTracker';
import MissionAdvisor from './components/MissionAdvisor';
import Lexicon from './components/Lexicon';

const App: React.FC = () => {
  const [view, setView] = useState<'dashboard' | 'profile' | 'meditation' | 'heroes' | 'advisor' | 'lexicon'>('dashboard');
  const [profile, setProfile] = useState<UserProfile>({
    spirit: {
      strengths: ['Strategic', 'Futuristic'],
      biblicalAnchors: ['Mark 2:2-4', 'Genesis 37:5-8']
    },
    soul: {
      mbti: 'INFJ',
      enneagram: '4',
      bigFive: {
        openness: 85,
        conscientiousness: 70,
        extraversion: 40,
        agreeableness: 90,
        neuroticism: 30
      }
    },
    body: {
      skills: ['Graphic Design', 'Writing'],
      hobbies: ['Digital Art', 'Hiking'],
      vitality: 75
    },
    currentWeek: 2
  });

  const getPhase = (week: number): JourneyPhase => {
    if (week <= 4) return JourneyPhase.FOUNDATIONS;
    if (week <= 8) return JourneyPhase.SHADOW_WORK;
    return JourneyPhase.ACTIVATION;
  };

  const navItem = (id: typeof view, label: string, icon: string) => (
    <button 
      onClick={() => setView(id)}
      className={`flex flex-col items-center p-3 transition-colors ${view === id ? 'text-[#D4AF37]' : 'text-slate-400 hover:text-slate-600'}`}
    >
      <i className={`fas ${icon} text-xl mb-1`}></i>
      <span className="text-[10px] uppercase tracking-widest font-bold">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen flex flex-col max-w-lg mx-auto bg-white shadow-2xl relative overflow-hidden">
      {/* Header */}
      <header className="px-6 pt-10 pb-6 text-center border-b border-slate-100 bg-white z-40 sticky top-0">
        <div className="flex justify-between items-center mb-4">
           <img src="https://picsum.photos/seed/nest/100/100" className="w-10 h-10 rounded-full border-2 border-[#D4AF37]/30 shadow-sm" alt="Logo" />
           <div className="text-right">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Phase: {getPhase(profile.currentWeek)}</p>
              <p className="text-xs text-indigo-600 font-medium italic">Week {profile.currentWeek} of 12</p>
           </div>
        </div>
        <h1 className="text-3xl font-serif text-slate-800">Nest Wholeness Engine</h1>
        <p className="text-slate-500 text-sm mt-1 italic italic">"Your whole spirit, soul, and body..."</p>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-24">
        {view === 'dashboard' && <Dashboard profile={profile} />}
        {view === 'profile' && <ProfileForm profile={profile} onSave={setProfile} />}
        {view === 'meditation' && <MeditationLab profile={profile} />}
        {view === 'heroes' && <HeroGallery profile={profile} />}
        {view === 'advisor' && <MissionAdvisor profile={profile} />}
        {view === 'lexicon' && <Lexicon />}
      </main>

      {/* Persistent Navigation */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-lg bg-white/90 backdrop-blur-lg border-t border-slate-100 flex justify-around items-center z-50 py-1">
        {navItem('dashboard', 'Home', 'fa-th-large')}
        {navItem('lexicon', 'Depth', 'fa-scroll')}
        {navItem('meditation', 'I AM', 'fa-heart')}
        {navItem('advisor', 'Mission', 'fa-sparkles')}
        {navItem('heroes', 'Heroes', 'fa-users')}
      </nav>
    </div>
  );
};

export default App;
