
export enum JourneyPhase {
  FOUNDATIONS = 'Foundations of Unity',
  SHADOW_WORK = 'Shadow & Stability',
  ACTIVATION = 'Mission Activation'
}

export interface UserProfile {
  spirit: {
    strengths: string[];
    archetype?: string;
    biblicalAnchors: string[];
  };
  soul: {
    mbti: string;
    enneagram: string;
    bigFive: {
      openness: number;
      conscientiousness: number;
      extraversion: number;
      agreeableness: number;
      neuroticism: number;
    };
  };
  body: {
    skills: string[];
    hobbies: string[];
    vitality: number; // 0-100
  };
  currentWeek: number;
}

export interface MissionHypothesis {
  statement: string;
  biblicalAnchor: string;
  jungianInsight: string;
  goldsmithAffirmation: string;
  practicalNextSteps: string[];
}

export interface StrengthMapping {
  theme: string;
  character: string;
  scripture: string;
  description: string;
}

export interface LinguisticTerm {
  term: string;
  language: string;
  literal_meaning: string;
  mystical_meaning: string;
  scripture_anchor: string;
  app_context: string;
  source_citation: string;
}
