
import { StrengthMapping, LinguisticTerm } from './types';

export interface ExtendedStrengthMapping extends StrengthMapping {
  linguisticTerm?: string;
  scientificFocus: string;
}

export const STRENGTHS_MAPPING: Record<string, ExtendedStrengthMapping> = {
  "Learner": {
    theme: "Learner",
    character: "Ezra",
    scripture: "Ezra 7:10",
    description: "The joy of the process. Sitting at the feet of the Truth to study, do, and teach.",
    linguisticTerm: "Phronesis",
    scientificFocus: "Continuous improvement and the process of learning over the outcome."
  },
  "Strategic": {
    theme: "Strategic",
    character: "The Friends of the Paralytic",
    scripture: "Mark 2:2-4",
    description: "Seeing the way when others see walls. Like the men who tore the roof off, you find the creative path.",
    linguisticTerm: "Phronesis",
    scientificFocus: "Sorting through clutter to find the best route; pattern recognition."
  },
  "Connectedness": {
    theme: "Connectedness",
    character: "Paul",
    scripture: "Romans 8:28",
    description: "The realization that nothing is a coincidence. Every event is a thread in the divine tapestry of reconciliation.",
    linguisticTerm: "Koinonia",
    scientificFocus: "Faith in the links between all things; bridge-building."
  },
  "Futuristic": {
    theme: "Futuristic",
    character: "Joseph",
    scripture: "Genesis 37:5-8",
    description: "Visionary foresight that anchors present faithfulness. Dreaming of the harvest while in the pit.",
    linguisticTerm: "Elpis",
    scientificFocus: "Inspiration from the future; visualizing what could be."
  },
  "Activator": {
    theme: "Activator",
    character: "Peter",
    scripture: "Acts 2:14-41",
    description: "Boldness that initiates movement. Peter's impulsive energy was transformed into the spark of the early church.",
    linguisticTerm: "Dunameis",
    scientificFocus: "Turning thoughts into action; impatience with inactivity."
  },
  "Achiever": {
    theme: "Achiever",
    character: "Nehemiah",
    scripture: "James 2:14-17",
    description: "Tireless drive to build and complete. Nehemiah's relentless focus on the wall reflects the faith that works.",
    linguisticTerm: "Dunameis",
    scientificFocus: "High stamina and hard work; satisfaction from accomplishment."
  },
  "Empathy": {
    theme: "Empathy",
    character: "Jesus",
    scripture: "John 11:33-35",
    description: "Compassionate presence without enmeshment. Feeling with others as a divine bridge.",
    linguisticTerm: "Ruach",
    scientificFocus: "Sensing the emotions of others; imagining oneself in their lives."
  },
  "Relator": {
    theme: "Relator",
    character: "Ruth",
    scripture: "Ruth 1:16-17",
    description: "The cord of three strands. Deep commitment and loyalty in intimate circles.",
    linguisticTerm: "Koinonia",
    scientificFocus: "Enjoying close relationships; working hard with friends to achieve a goal."
  }
};

export const ENNEAGRAM_DATA: Record<string, { virtue: string; shadow: string }> = {
  "1": { virtue: "Serenity", shadow: "Resentment" },
  "2": { virtue: "Humility", shadow: "Pride" },
  "3": { virtue: "Veracity", shadow: "Deceit" },
  "4": { virtue: "Equanimity", shadow: "Envy" },
  "5": { virtue: "Detachment", shadow: "Avarice" },
  "6": { virtue: "Courage", shadow: "Fear" },
  "7": { virtue: "Sobriety", shadow: "Gluttony" },
  "8": { virtue: "Innocence", shadow: "Lust" },
  "9": { virtue: "Action", shadow: "Sloth" },
};

export const WEEKLY_CURRICULUM = [
  { week: 1, title: "Foundations of Unity", focus: "Spirit: The I AM presence" },
  { week: 2, title: "Diagnostic Baseline", focus: "Soul: Strengths & Personality" },
  { week: 3, title: "Sacred Endowments", focus: "Spirit: Biblical Archetypes" },
  { week: 4, title: "Triune Alignment", focus: "Body: Vitality & Flow" },
  { week: 5, title: "Shadow Work Begins", focus: "Soul: Integrating the Repressed" },
  { week: 6, title: "Emotional Resilience", focus: "Soul: Enneagram Stress Arrows" },
  { week: 7, title: "The Gateway of Hobbies", focus: "Body: Latent Talents" },
  { week: 8, title: "Stability in the Christ", focus: "Spirit: Silent Contemplation" },
  { week: 9, title: "Skill Stacking", focus: "Body: Practical Preparation" },
  { week: 10, title: "Mission Hypothesis", focus: "Spirit: Discerning the Call" },
  { week: 11, title: "Redemptive Investment", focus: "Soul: Leveraging Shadow for Light" },
  { week: 12, title: "Activation", focus: "Body: The First Step of Faith" },
];

export const CHRIST_CONSCIOUSNESS_DATASET: LinguisticTerm[] = [
  {
    "term": "Metanoia",
    "language": "Greek",
    "literal_meaning": "Repentance / Change of mind",
    "mystical_meaning": "Transcending the Mind: Moving beyond the dualistic ego-intellect into the non-dual awareness of the Spirit.",
    "scripture_anchor": "Romans 12:2",
    "app_context": "Phase 1: Awakening the Inner Christ",
    "source_citation": "[3], [6]"
  },
  {
    "term": "Emet",
    "language": "Hebrew",
    "literal_meaning": "Truth",
    "mystical_meaning": "Divine Stability: That which is firm and unchanging; realizing your identity is anchored in the Eternal.",
    "scripture_anchor": "Psalm 25:5",
    "app_context": "Soul Pillar: Emotional Stability",
    "source_citation": "[3], [7]"
  },
  {
    "term": "Kenosis",
    "language": "Greek",
    "literal_meaning": "Emptying",
    "mystical_meaning": "Self-Emptying: The process of shedding the false self (ego) so the Divine Presence can flow unobstructed.",
    "scripture_anchor": "Philippians 2:7",
    "app_context": "Spirit Pillar: Contemplative Silence",
    "source_citation": "[3]"
  },
  {
    "term": "Koinonia",
    "language": "Greek",
    "literal_meaning": "Fellowship / Participation",
    "mystical_meaning": "Relational Oneness: The realization of the 'cord of three strands' that connects the individual to the Body of Christ.",
    "scripture_anchor": "Ecclesiastes 4:12",
    "app_context": "Relator Strength Reflection",
    "source_citation": "[8], [9]"
  },
  {
    "term": "Phronesis",
    "language": "Greek",
    "literal_meaning": "Practical Wisdom / Prudence",
    "mystical_meaning": "Strategic Discernment: The ability to see God-provided paths or 'ways out' through complexity.",
    "scripture_anchor": "1 Corinthians 10:13",
    "app_context": "Strategic Strength Reflection",
    "source_citation": "[7]"
  },
  {
    "term": "Elpis",
    "language": "Greek",
    "literal_meaning": "Hope / Expectation",
    "mystical_meaning": "Futuristic Vision: Being energized by God's prepared future rather than being limited by present circumstances.",
    "scripture_anchor": "Jeremiah 29:11",
    "app_context": "Futuristic Strength Reflection",
    "source_citation": "[10], [11]"
  },
  {
    "term": "Charisma",
    "language": "Greek",
    "literal_meaning": "Gift of Grace",
    "mystical_meaning": "Sacred Endowment: A specific talent (CliftonStrength) distributed by the Spirit for the common good.",
    "scripture_anchor": "1 Corinthians 12:7",
    "app_context": "Mission Discernment: Skill Stacking",
    "source_citation": "[12], [8]"
  },
  {
    "term": "Shalom",
    "language": "Hebrew",
    "literal_meaning": "Peace / Completeness",
    "mystical_meaning": "Triune Wholeness: The state of being 'kept blameless' and integrated across spirit, soul, and body.",
    "scripture_anchor": "1 Thessalonians 5:23",
    "app_context": "Phase 2: Embodying Wholeness",
    "source_citation": "[13], [8]"
  },
  {
    "term": "Ruach",
    "language": "Hebrew",
    "literal_meaning": "Breath / Wind / Spirit",
    "mystical_meaning": "Divine Flow: The movement of God within the human temple, activated through rhythmic meditation.",
    "scripture_anchor": "Joel 3:1",
    "app_context": "Hesychastic Timer: Breathing Rhythm",
    "source_citation": "[10], [2]"
  },
  {
    "term": "Dunameis",
    "language": "Greek",
    "literal_meaning": "Power / Miraculous Ability",
    "mystical_meaning": "Talent Multiplier: The spiritual energy used to 'invest' your innate gifts rather than burying them.",
    "scripture_anchor": "Matthew 25:14-30",
    "app_context": "Mission Activation: Investing Talents",
    "source_citation": "[12], [8]"
  }
];
