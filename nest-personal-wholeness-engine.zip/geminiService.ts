
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, MissionHypothesis } from "./types";

const SYSTEM_INSTRUCTION = `
You are the "Nest Personal Wholeness Engine" and the "Golden Thread Engine." 
Your mission is to perform deep cross-analysis of personality data to fulfill a user's God-given mission.

FRAMEWORK:
1. Spirit: Realizing oneness via CliftonStrengths treated as "Sacred Endowments" (Matthew 25). Invest talents, don't bury them.
2. Soul: Psychological wholeness via Jungian Shadow Work, Enneagram (virtues/holy ideas), and MBTI cognitive processing.
3. Body: Practical skill stacking and vitality.

GOLDEN THREAD LOGIC:
- Scan Gallup/CliftonStrengths themes (e.g. Connectedness) + Enneagram Type (e.g. Type 9) to suggest high-impact kingdom missions (e.g. Unification/Reconciliation).
- Map scientific traits to "Linguistic Depth" (Metanoia, Phronesis, Elpis, etc.).
- Always anchor findings in Scripture (1 Thess 5:23, Matthew 25:14-30, Romans 8:28).

RESPONSE FORMAT:
You must respond in JSON matching the specified schema. Be mystical yet analytically precise.
`;

export class WholenessEngineService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async generateMission(profile: UserProfile): Promise<MissionHypothesis> {
    const prompt = `Golden Thread Analysis Request:
    Profile Data: ${JSON.stringify(profile)}
    
    Cross-analyze the interaction between:
    - Gallup Strengths: ${profile.spirit.strengths.join(', ')}
    - Enneagram: Type ${profile.soul.enneagram}
    - MBTI: ${profile.soul.mbti}
    - Skills: ${profile.body.skills.join(', ')}
    
    Synthesize these into a Mission Hypothesis that follows the "Invest your Talents" mandate of Matthew 25.`;

    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            statement: { type: Type.STRING, description: "A one-paragraph mission hypothesis synthesis." },
            biblicalAnchor: { type: Type.STRING, description: "The core scripture anchor for this specific cross-analysis." },
            jungianInsight: { type: Type.STRING, description: "The psychological integration needed (Shadow Work)." },
            goldsmithAffirmation: { type: Type.STRING, description: "A contemplative 'I AM' affirmation." },
            practicalNextSteps: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "3 steps to physically manifest this mission (Body layer)."
            }
          },
          required: ["statement", "biblicalAnchor", "jungianInsight", "goldsmithAffirmation", "practicalNextSteps"]
        }
      }
    });

    try {
      return JSON.parse(response.text || '{}');
    } catch (e) {
      console.error("Failed to parse Mission Hypothesis", e);
      throw e;
    }
  }

  async getReflections(profile: UserProfile, query: string): Promise<string> {
    const prompt = `User Query: ${query}. 
    Context: Week ${profile.currentWeek} of the Nest journey. 
    Analyze using the Golden Thread Engine.`;

    const response = await this.ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });

    return response.text || "I am contemplating the Golden Threads of your journey.";
  }
}
