
import React, { useState } from 'react';
import { CHRIST_CONSCIOUSNESS_DATASET } from '../constants';
import { LinguisticTerm } from '../types';

const Lexicon: React.FC = () => {
  const [selectedTerm, setSelectedTerm] = useState<LinguisticTerm | null>(null);

  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif text-slate-800">Linguistic Depth</h2>
        <p className="text-slate-500 text-sm">The Golden Threads of Christ Consciousness</p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {CHRIST_CONSCIOUSNESS_DATASET.map((item) => (
          <button
            key={item.term}
            onClick={() => setSelectedTerm(item)}
            className="text-left bg-white border border-slate-100 rounded-3xl p-6 shadow-sm hover:shadow-md transition-all group flex justify-between items-center"
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] opacity-80">
                  {item.language}
                </span>
                <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
                <span className="text-[10px] font-medium text-slate-400">
                  {item.app_context}
                </span>
              </div>
              <h3 className="text-xl font-serif text-slate-800 group-hover:text-[#D4AF37] transition-colors">{item.term}</h3>
              <p className="text-xs text-slate-400 italic mt-1">{item.literal_meaning}</p>
            </div>
            <i className="fas fa-chevron-right text-slate-200 group-hover:text-[#D4AF37] group-hover:translate-x-1 transition-all"></i>
          </button>
        ))}
      </div>

      {/* Pop-out Overlay */}
      {selectedTerm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[60] flex items-end sm:items-center justify-center p-4 animate-in fade-in duration-300" onClick={() => setSelectedTerm(null)}>
          <div 
            className="bg-white w-full max-w-md rounded-t-[40px] sm:rounded-[40px] p-8 shadow-2xl relative animate-in slide-in-from-bottom duration-500"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setSelectedTerm(null)}
              className="absolute top-6 right-6 w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600"
            >
              <i className="fas fa-times"></i>
            </button>

            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-[#D4AF37]">
                  <i className="fas fa-scroll text-xl"></i>
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#D4AF37]">{selectedTerm.language} Depth</p>
                  <h3 className="text-3xl font-serif text-slate-900">{selectedTerm.term}</h3>
                </div>
              </div>
              <p className="text-sm font-medium text-slate-400 italic border-l-2 border-[#D4AF37] pl-4">
                Literal: {selectedTerm.literal_meaning}
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-amber-50/50 p-6 rounded-3xl border border-amber-100">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] mb-3">Mystical Realization</h4>
                <p className="text-slate-800 leading-relaxed text-sm font-medium">
                  {selectedTerm.mystical_meaning}
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-indigo-600">
                  <i className="fas fa-anchor text-xs"></i>
                  <span className="text-sm font-bold">{selectedTerm.scripture_anchor}</span>
                </div>
                <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">
                  Ref: {selectedTerm.source_citation}
                </p>
              </div>

              <button 
                onClick={() => setSelectedTerm(null)}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold shadow-lg hover:bg-black transition-all"
              >
                Integrate into Being
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Lexicon;
