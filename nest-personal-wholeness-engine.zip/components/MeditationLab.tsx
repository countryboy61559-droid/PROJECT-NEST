
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';

interface MeditationLabProps {
  profile: UserProfile;
}

const MeditationLab: React.FC<MeditationLabProps> = ({ profile }) => {
  const [isActive, setIsActive] = useState(false);
  const [seconds, setSeconds] = useState(300); // 5 mins
  const [affirmationIdx, setAffirmationIdx] = useState(0);

  const affirmations = [
    "I am one with the Father.",
    "The Christ within me is my sufficiency.",
    "Peace, be still.",
    "My body is a prepared channel for divine flow.",
    "I live, yet not I, but Christ liveth in me."
  ];

  useEffect(() => {
    let interval: any;
    if (isActive && seconds > 0) {
      interval = setInterval(() => setSeconds(s => s - 1), 1000);
    } else if (seconds === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const nextAffirmation = () => setAffirmationIdx((affirmationIdx + 1) % affirmations.length);

  return (
    <div className="p-6 text-center space-y-10 min-h-full flex flex-col items-center justify-center animate-in slide-in-from-bottom duration-700">
      <div className="space-y-4">
        <i className="fas fa-om text-indigo-400 text-4xl animate-pulse"></i>
        <h2 className="text-3xl font-serif text-slate-800">Goldsmith Lab</h2>
        <p className="text-slate-400 text-sm italic">"Silence is the language of God."</p>
      </div>

      <div className="w-64 h-64 rounded-full border-4 border-slate-50 flex flex-items-center justify-center flex-col relative overflow-hidden shadow-inner">
         <div 
           className="absolute bottom-0 left-0 w-full bg-indigo-50 transition-all duration-1000" 
           style={{ height: `${(seconds / 300) * 100}%`, opacity: 0.3 }}
         />
         <span className="text-5xl font-light text-slate-700 font-serif relative z-10">{formatTime(seconds)}</span>
      </div>

      <div className="px-8 min-h-[80px]">
        <p className="text-xl font-serif text-indigo-900 italic animate-in fade-in key={affirmationIdx}">
          "{affirmations[affirmationIdx]}"
        </p>
      </div>

      <div className="flex gap-4 w-full">
        <button 
          onClick={() => setIsActive(!isActive)}
          className={`flex-1 py-4 rounded-2xl font-bold transition-all shadow-lg ${isActive ? 'bg-amber-100 text-amber-800' : 'bg-indigo-600 text-white shadow-indigo-200'}`}
        >
          {isActive ? 'Pause Stillness' : 'Enter Silence'}
        </button>
        <button 
          onClick={nextAffirmation}
          className="w-16 h-16 bg-slate-100 text-slate-600 rounded-2xl hover:bg-slate-200"
        >
          <i className="fas fa-redo-alt"></i>
        </button>
      </div>

      <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 text-left w-full">
        <h4 className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-2">Contemplative Prompt</h4>
        <p className="text-xs text-indigo-800 leading-relaxed italic">
          As an Enneagram Type {profile.soul.enneagram}, notice the inner "judge" or "striving." Allow it to dissolve into the I AM consciousness.
        </p>
      </div>
    </div>
  );
};

export default MeditationLab;
