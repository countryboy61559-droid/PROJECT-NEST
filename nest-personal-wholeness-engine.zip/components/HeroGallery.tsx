
import React, { useState } from 'react';
import { UserProfile, LinguisticTerm } from '../types';
import { STRENGTHS_MAPPING, CHRIST_CONSCIOUSNESS_DATASET } from '../constants';

interface HeroGalleryProps {
  profile: UserProfile;
}

const HeroGallery: React.FC<HeroGalleryProps> = ({ profile }) => {
  const [selectedStrength, setSelectedStrength] = useState<string | null>(null);

  const mapping = selectedStrength ? STRENGTHS_MAPPING[selectedStrength] : null;
  const linguisticDepth = mapping?.linguisticTerm 
    ? CHRIST_CONSCIOUSNESS_DATASET.find(t => t.term === mapping.linguisticTerm)
    : null;

  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif text-slate-800">Heroes of the Faith</h2>
        <p className="text-slate-500 text-sm italic">Tap your sacred endowments to reveal Depth</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {profile.spirit.strengths.map((strength) => {
          const m = STRENGTHS_MAPPING[strength];
          if (!m) return null;

          return (
            <button
              key={strength}
              onClick={() => setSelectedStrength(strength)}
              className="group text-left bg-white border border-slate-100 rounded-[32px] p-6 shadow-sm hover:shadow-xl hover:border-[#D4AF37]/30 transition-all active:scale-95"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#D4AF37] bg-amber-50 px-3 py-1 rounded-full group-hover:bg-[#D4AF37] group-hover:text-white transition-colors">
                    {strength}
                  </span>
                  <h3 className="text-2xl font-serif text-slate-800 mt-3 group-hover:text-[#D4AF37] transition-colors">
                    {m.character}
                  </h3>
                </div>
                <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200 group-hover:text-[#D4AF37] transition-colors">
                   <i className="fas fa-fingerprint text-xl"></i>
                </div>
              </div>
              
              <p className="text-sm text-slate-600 mb-4 leading-relaxed font-medium">
                {m.description}
              </p>

              <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                 <div className="flex items-center gap-2 text-indigo-600">
                    <i className="fas fa-book-open text-[10px]"></i>
                    <span className="text-[10px] font-black uppercase tracking-widest">{m.scripture}</span>
                 </div>
                 <span className="text-[10px] font-bold text-slate-300 uppercase">Parallaxis Ready</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Pop-out Card (Parallaxis Hover System) */}
      {selectedStrength && mapping && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[60] flex items-center justify-center p-6 animate-in fade-in duration-300"
          onClick={() => setSelectedStrength(null)}
        >
          <div 
            className="bg-white w-full max-w-md rounded-[48px] overflow-hidden shadow-2xl relative animate-in zoom-in-95 duration-500"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header / Banner */}
            <div className="bg-[#D4AF37] h-32 flex items-end justify-center pb-6">
                <div className="bg-white p-4 rounded-3xl shadow-lg -mb-12">
                   <i className="fas fa-star text-[#D4AF37] text-2xl"></i>
                </div>
            </div>

            <div className="px-8 pt-16 pb-10 space-y-6">
              <div className="text-center">
                <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#D4AF37] mb-2">Sacred Endowment</p>
                <h3 className="text-3xl font-serif text-slate-900">{mapping.theme}</h3>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Scientific Definition</h4>
                  <p className="text-xs text-slate-700 leading-relaxed font-medium italic">
                    {mapping.scientificFocus}
                  </p>
                </div>

                {linguisticDepth && (
                  <div className="bg-amber-50 p-5 rounded-3xl border border-amber-100 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-3 opacity-10">
                       <i className="fas fa-scroll text-3xl"></i>
                    </div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-[#D4AF37] mb-2">Linguistic Depth: {linguisticDepth.term}</h4>
                    <p className="text-xs text-amber-900 leading-relaxed font-serif">
                      {linguisticDepth.mystical_meaning}
                    </p>
                  </div>
                )}

                <div className="bg-indigo-900 text-white p-6 rounded-3xl shadow-xl">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                       <i className="fas fa-anchor text-[10px]"></i>
                    </div>
                    <span className="text-xs font-bold">{mapping.scripture}</span>
                  </div>
                  <p className="text-sm font-serif italic opacity-90 leading-relaxed">
                    Archetype: {mapping.character} — How this talent manifests in the redemptive arc of history.
                  </p>
                </div>
              </div>

              <button 
                onClick={() => setSelectedStrength(null)}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-black transition-all"
              >
                Close Depth View
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-slate-900 text-white p-8 rounded-[40px] text-center space-y-4 shadow-2xl">
        <p className="text-[#D4AF37] text-[10px] font-black uppercase tracking-[0.4em]">Stewardship</p>
        <p className="text-lg font-serif leading-relaxed italic">
          "For to everyone who has, more will be given, and he will have abundance..."
        </p>
        <p className="text-[10px] font-bold opacity-40 uppercase">— Matthew 25:29</p>
      </div>
    </div>
  );
};

export default HeroGallery;
