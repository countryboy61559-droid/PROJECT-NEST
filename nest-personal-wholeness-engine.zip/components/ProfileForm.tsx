
import React from 'react';
import { UserProfile } from '../types';

interface ProfileFormProps {
  profile: UserProfile;
  onSave: (p: UserProfile) => void;
}

const ProfileForm: React.FC<ProfileFormProps> = ({ profile, onSave }) => {
  const [local, setLocal] = React.useState(profile);

  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif text-slate-800">Your Nest</h2>
        <p className="text-slate-500 text-sm">Update your Triune Alignment</p>
      </div>

      <div className="space-y-6">
        {/* Spirit Layer */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <i className="fas fa-dove text-indigo-500 text-sm"></i>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Spirit (Strengths)</h3>
          </div>
          <div className="grid grid-cols-2 gap-2">
             {['Strategic', 'Futuristic', 'Relator', 'Empathy', 'Learner', 'Command', 'Activator', 'Achiever'].map(s => (
               <button
                 key={s}
                 onClick={() => {
                   const exists = local.spirit.strengths.includes(s);
                   const next = exists 
                     ? local.spirit.strengths.filter(x => x !== s)
                     : [...local.spirit.strengths, s].slice(0, 5);
                   setLocal({ ...local, spirit: { ...local.spirit, strengths: next } });
                 }}
                 className={`py-2 px-3 rounded-xl text-[10px] font-bold border transition-all ${local.spirit.strengths.includes(s) ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-500 border-slate-200'}`}
               >
                 {s}
               </button>
             ))}
          </div>
        </section>

        {/* Soul Layer */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <i className="fas fa-brain text-teal-500 text-sm"></i>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Soul (Psychology)</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Enneagram</label>
              <select 
                value={local.soul.enneagram}
                onChange={e => setLocal({ ...local, soul: { ...local.soul, enneagram: e.target.value } })}
                className="w-full bg-slate-50 border-0 rounded-xl p-3 text-sm font-medium focus:ring-2 focus:ring-teal-500"
              >
                {[1,2,3,4,5,6,7,8,9].map(n => <option key={n} value={n.toString()}>Type {n}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">MBTI</label>
              <input 
                value={local.soul.mbti}
                onChange={e => setLocal({ ...local, soul: { ...local.soul, mbti: e.target.value.toUpperCase() } })}
                className="w-full bg-slate-50 border-0 rounded-xl p-3 text-sm font-medium focus:ring-2 focus:ring-teal-500"
                placeholder="e.g. INFJ"
              />
            </div>
          </div>
        </section>

        {/* Body Layer */}
        <section className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <i className="fas fa-running text-amber-500 text-sm"></i>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-400">Body (Practical)</h3>
          </div>
          <div className="space-y-3">
             <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Vitality Score (0-100)</label>
              <input 
                type="range"
                value={local.body.vitality}
                onChange={e => setLocal({ ...local, body: { ...local.body, vitality: parseInt(e.target.value) } })}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[10px] font-bold text-slate-400">
                <span>REPOSE</span>
                <span>{local.body.vitality}%</span>
                <span>DYNAMIC</span>
              </div>
            </div>
          </div>
        </section>

        <button 
          onClick={() => onSave(local)}
          className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-black transition-all shadow-xl"
        >
          Save Wholeness Profile
        </button>
      </div>
    </div>
  );
};

export default ProfileForm;
