
import React from 'react';
import { UserProfile } from '../types';
import { WEEKLY_CURRICULUM } from '../constants';

interface DashboardProps {
  profile: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ profile }) => {
  const alignmentScore = Math.floor((profile.body.vitality + 80 + 90) / 3);
  
  // Find the curriculum data for the current week
  const currentWeekData = WEEKLY_CURRICULUM.find(w => w.week === profile.currentWeek) || WEEKLY_CURRICULUM[0];

  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      {/* Wholeness Wheel Simulation */}
      <div className="relative aspect-square max-w-[280px] mx-auto flex items-center justify-center">
        <div className="absolute inset-0 rounded-full border-[12px] border-indigo-50 opacity-20"></div>
        <div className="absolute inset-4 rounded-full border-[12px] border-teal-50 opacity-40"></div>
        <div className="absolute inset-8 rounded-full border-[12px] border-amber-50 opacity-60"></div>
        
        <div className="text-center z-10">
          <p className="text-xs uppercase tracking-[0.2em] font-bold text-slate-400 mb-1">Integration</p>
          <span className="text-6xl font-serif text-slate-800">{alignmentScore}%</span>
          <p className="text-xs font-medium text-indigo-600 mt-1 italic">Triune Alignment</p>
        </div>
      </div>

      {/* Three Pillars Summary */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-indigo-50/50 p-5 rounded-3xl border border-indigo-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center text-xs">
              <i className="fas fa-dove"></i>
            </div>
            <h3 className="font-bold text-indigo-900">Spirit</h3>
          </div>
          <p className="text-xs text-indigo-700 leading-relaxed">
            Anchored in {profile.spirit.strengths.slice(0, 2).join(' and ')}. 
            Cultivating the "Inner Christ" awareness.
          </p>
        </div>

        <div className="bg-teal-50/50 p-5 rounded-3xl border border-teal-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-teal-600 text-white rounded-full flex items-center justify-center text-xs">
              <i className="fas fa-brain"></i>
            </div>
            <h3 className="font-bold text-teal-900">Soul</h3>
          </div>
          <p className="text-xs text-teal-700 leading-relaxed">
            Type {profile.soul.enneagram} ({profile.soul.mbti}). 
            Working towards Jungian individuation.
          </p>
        </div>

        <div className="bg-amber-50/50 p-5 rounded-3xl border border-amber-100">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-amber-600 text-white rounded-full flex items-center justify-center text-xs">
              <i className="fas fa-running"></i>
            </div>
            <h3 className="font-bold text-amber-900">Body</h3>
          </div>
          <p className="text-xs text-amber-700 leading-relaxed">
            Vitality at {profile.body.vitality}%. 
            Skills: {profile.body.skills.join(', ')}.
          </p>
        </div>
      </div>

      {/* Current Weekly Focus */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-xl shadow-indigo-100 border border-slate-800">
        <p className="text-[10px] uppercase tracking-widest font-bold opacity-60 mb-2">Weekly Objective (Week {currentWeekData.week} of 12)</p>
        <h4 className="text-xl font-serif mb-1">{currentWeekData.title}</h4>
        <p className="text-xs text-indigo-300 italic mb-4">{currentWeekData.focus}</p>
        
        <div className="h-1 bg-slate-700 rounded-full mb-4 overflow-hidden">
          <div 
            className="h-full bg-[#D4AF37] transition-all duration-1000" 
            style={{ width: `${(profile.currentWeek / 12) * 100}%` }}
          ></div>
        </div>
        
        <button className="w-full py-3 bg-white text-slate-900 rounded-xl text-sm font-bold hover:bg-slate-50 transition-colors">
          Begin Reflection
        </button>
      </div>
    </div>
  );
};

export default Dashboard;
