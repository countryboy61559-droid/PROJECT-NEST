
import React, { useState, useEffect } from 'react';
import { UserProfile, MissionHypothesis } from '../types';
import { WholenessEngineService } from '../geminiService';

interface MissionAdvisorProps {
  profile: UserProfile;
}

const MissionAdvisor: React.FC<MissionAdvisorProps> = ({ profile }) => {
  const [loading, setLoading] = useState(false);
  const [hypothesis, setHypothesis] = useState<MissionHypothesis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const engine = new WholenessEngineService();

  const generateMission = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await engine.generateMission(profile);
      setHypothesis(result);
    } catch (err) {
      setError("Failed to consult the Golden Thread Engine. Verify your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif text-slate-800">Golden Thread Engine</h2>
        <p className="text-slate-500 text-sm italic">Synthesizing Spirit, Soul, and Body</p>
      </div>

      {!hypothesis && !loading && (
        <div className="bg-white border border-slate-100 p-8 rounded-[40px] shadow-sm text-center space-y-6 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-b from-amber-50/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          
          <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto shadow-inner relative">
            <i className="fas fa-dna text-[#D4AF37] text-3xl animate-pulse"></i>
          </div>
          
          <div className="space-y-3">
            <h4 className="text-xl font-serif text-slate-800">Discerning Your Mission</h4>
            <p className="text-xs text-slate-500 leading-relaxed max-w-[240px] mx-auto">
              Our AI cross-analyzes your <strong>{profile.spirit.strengths.length} Gallup themes</strong>, 
              <strong>Type {profile.soul.enneagram}</strong> personality, and 
              <strong>{profile.body.skills.length} skills</strong> to define your redemptive path.
            </p>
          </div>

          <button 
            onClick={generateMission}
            className="w-full py-4 bg-slate-900 text-white rounded-3xl font-bold hover:bg-black shadow-xl transition-all active:scale-95"
          >
            Initialize Golden Thread
          </button>
        </div>
      )}

      {loading && (
        <div className="p-16 text-center space-y-6">
          <div className="relative w-16 h-16 mx-auto">
             <div className="absolute inset-0 border-4 border-[#D4AF37]/20 rounded-full"></div>
             <div className="absolute inset-0 border-4 border-t-[#D4AF37] rounded-full animate-spin"></div>
          </div>
          <div className="space-y-2">
            <p className="text-[10px] font-black uppercase tracking-[0.3em] text-[#D4AF37]">Cross-Analyzing</p>
            <p className="text-slate-400 text-xs italic">"Connecting the sacred endowments..."</p>
          </div>
        </div>
      )}

      {error && (
        <div className="p-5 bg-red-50 text-red-600 text-xs rounded-2xl border border-red-100 flex items-center gap-3">
          <i className="fas fa-exclamation-circle"></i>
          {error}
        </div>
      )}

      {hypothesis && (
        <div className="space-y-6 animate-in zoom-in-95 duration-700">
          <div className="bg-[#D4AF37] p-8 rounded-[48px] text-white shadow-2xl relative overflow-hidden">
             <div className="absolute -top-10 -left-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
             <p className="text-[10px] font-black uppercase tracking-[0.4em] mb-4 opacity-70">The Mission Hypothesis</p>
             <p className="text-xl font-serif italic leading-relaxed">
               "{hypothesis.statement}"
             </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div className="bg-white border border-slate-100 p-6 rounded-[32px] hover:border-[#D4AF37]/30 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                 <i className="fas fa-anchor text-indigo-500"></i>
                 <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Biblical Anchor</h4>
              </div>
              <p className="text-sm text-slate-800 font-medium">{hypothesis.biblicalAnchor}</p>
            </div>

            <div className="bg-white border border-slate-100 p-6 rounded-[32px] hover:border-teal-500/30 transition-colors">
              <div className="flex items-center gap-3 mb-3">
                 <i className="fas fa-moon text-teal-500"></i>
                 <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Shadow Integration</h4>
              </div>
              <p className="text-sm text-slate-800 font-medium italic">"{hypothesis.jungianInsight}"</p>
            </div>

            <div className="bg-slate-900 text-white p-6 rounded-[32px] shadow-lg">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-[#D4AF37] mb-4">Invested Talents (Matthew 25)</h4>
              <ul className="space-y-4">
                {hypothesis.practicalNextSteps.map((step, i) => (
                  <li key={i} className="flex gap-4 items-start">
                    <span className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center text-[10px] flex-shrink-0 mt-0.5">
                       {i+1}
                    </span>
                    <p className="text-xs font-medium opacity-90 leading-relaxed">{step}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="p-6 border-2 border-dashed border-slate-100 rounded-[32px] text-center">
             <p className="text-[10px] font-black uppercase tracking-widest text-slate-300 mb-3">Silent Contemplation</p>
             <p className="text-sm font-serif italic text-indigo-900">"{hypothesis.goldsmithAffirmation}"</p>
          </div>

          <button 
            onClick={() => setHypothesis(null)}
            className="w-full py-4 text-slate-400 text-[10px] font-black uppercase tracking-[0.4em] hover:text-[#D4AF37] transition-all"
          >
            Refine & Re-Synthesize
          </button>
        </div>
      )}
    </div>
  );
};

export default MissionAdvisor;
